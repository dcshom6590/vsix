export const paintsToCSS = (paints, opacity = 1) => {
    return paints?.filter(paint => paint.visible)?.map(paint => paintToCSS(paint, opacity));
};

const paintToCSS = (paint, opacity) => {
    const combinedOpacity = (paint.opacity ?? 1) * opacity;

    switch (paint.type) {
        case "SOLID":
            return solidToCSS(paint.color, combinedOpacity);

        case "GRADIENT_LINEAR":
            return linearGradientToCSS(paint);

        case "GRADIENT_RADIAL":
            return radialGradientToCSS(paint);

        case "GRADIENT_ANGULAR":
            return conicGradientToCSS(paint);

        case "GRADIENT_DIAMOND":
            return radialGradientToCSS(paint); // Fallback

        case "IMAGE":
        case "EMOJI":
        case "VIDEO":
        case "PATTERN":
            return null; // Handle separately or fallback

        default:
            return "transparent";
    }
}

const solidToCSS = (color, opacity) => {
    if (opacity === 1) {
        const r = Math.round(color.r * 255);
        const g = Math.round(color.g * 255);
        const b = Math.round(color.b * 255);
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    } else {
        return `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${opacity})`;
    }
}

const linearGradientToCSS = (paint) => {
    const handles = paint.gradientHandlePositions;
    const angle = getLinearGradientAngle(handles);
    const stops = paint.gradientStops
        .map(stop => `${solidToCSS(stop.color, 1)} ${Math.round(stop.position * 100)}%`)
        .join(', ');
    return `linear-gradient(${Math.round(angle)}deg, ${stops})`;
}

const radialGradientToCSS = (paint) => {
    const center = paint.gradientHandlePositions[0];
    const stops = paint.gradientStops
        .map(stop => `${solidToCSS(stop.color, 1)} ${Math.round(stop.position * 100)}%`)
        .join(', ');
    return `radial-gradient(circle at ${Math.round(center.x * 100)}% ${Math.round(center.y * 100)}%, ${stops})`;
}

const conicGradientToCSS = (paint) => {
    const center = paint.gradientHandlePositions[0];
    const stops = paint.gradientStops
        .map(stop => `${solidToCSS(stop.color, 1)} ${Math.round(stop.position * 360)}deg`)
        .join(', ');
    return `conic-gradient(from 0deg at ${Math.round(center.x * 100)}% ${Math.round(center.y * 100)}%, ${stops})`;
}
