export const effectsToCSS = (effects) => {
    return effects?.map(effect => effectToCSS(effect)) ?? [];
};


const effectToCSS = (effect) => {
    if (['DROP_SHADOW', 'INNER_SHADOW'].includes(effect.type)) {
        return 'box-shadow: ' + shadowToCSS(effect);
    } else if (effect.type === 'LAYER_BLUR') {
        return 'filter: ' + layerBlurToCSS(effect);
    } else if (effect.type === 'BACKGROUND_BLUR') {
        return 'backdrop-filter: ' + layerBlurToCSS(effect);
    }
}

const shadowToCSS = (effect) => {
    const { offset, radius, spread = 0, color } = effect;
    const x = offset.x;
    const y = offset.y;
    const blur = radius;
    const spreadValue = spread;

    // Convert color to rgba
    const r = Math.round(color.r * 255);
    const g = Math.round(color.g * 255);
    const b = Math.round(color.b * 255);
    const a = color.a ?? 1;

    const colorString = `rgba(${r}, ${g}, ${b}, ${a})`;

    // Add "inset" for inner shadows
    const inset = effect.type === "INNER_SHADOW" ? "inset " : "";

    return `${inset}${x}px ${y}px ${blur}px ${spreadValue}px ${colorString}`;
}

const layerBlurToCSS = (effect) => {

    return `blur(${effect.radius}px)`;
}
