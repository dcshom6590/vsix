import { effectsToCSS } from "./effectsToCSS.mjs";
import { paddingToCSS } from "./paddingToCSS.mjs";
import { paintsToCSS } from "./paintsToCSS.mjs";

const textStyle = (style) => {
    const requiredProps = [
        "fontFamily",
        "fontSize",
        "textAlignHorizontal",
        "letterSpacing",
        "fontWeight",
        "textDecoration",
        "textCase",
    ];

    const output = {};

    for (const prop of requiredProps) {
        if (style.hasOwnProperty(prop)) {
            output[prop] = style[prop];
        }
    }

    if (style.lineHeightUnit === "FONT_SIZE_%") {
        output["lineHeight"] = style.lineHeightPercentFontSize / 100 ?? 1;
    }

    return output;
};

const extractFrame = (node) => {
    const requiredProps = [
        // Layout mode
        "layoutMode",
        "layoutSizingHorizontal",
        "layoutSizingVertical",
        "layoutWrap",

        // Sizing modes (auto-layout)
        "primaryAxisSizingMode",
        "counterAxisSizingMode",

        // Alignment
        "primaryAxisAlignItems",
        "counterAxisAlignItems",
        "counterAxisAlignContent",

        // Spacing
        "itemSpacing",
        "counterAxisSpacing",

        // Dimensions
        "width",
        "height",
        "minWidth",
        "minHeight",
        "maxWidth",
        "maxHeight",

        // Child layout
        "layoutAlign",
        "layoutGrow",

        // Borders
        "strokeWeight",
        "strokeAlign",
        "cornerRadius",
        "rectangleCornerRadii",

        // Visual
        "opacity",
        "blendMode",

        // Overflow
        "clipsContent",

        // Positioning
        "layoutPositioning",
        "constraints",

        // Advanced
        "strokesIncludedInLayout",

        "absoluteBoundingBox",
    ];

    const output = {};

    for (const prop of requiredProps) {
        if (node.hasOwnProperty(prop)) {
            output[prop] = node[prop];
        }
    }

    const fills = paintsToCSS(node.fills, node.opacity);
    if (fills?.length) {
        output.fills = fills;
    }

    const strokes = paintsToCSS(node.strokes, node.opacity);

    if (strokes?.length) {
        output.strokes = strokes;
    }

    const padding = paddingToCSS(node);
    if (padding) output.padding = padding;

    if (node?.effects?.length) {
        output.effects = effectsToCSS(node.effects);
    }

    return output;
};

const extractText = (node) => {
    const output = {
        characters: node.characters,
        style: textStyle(node.style),
    };

    const fills = paintsToCSS(node.fills, node.opacity);

    if (fills?.length) {
        output.fills = fills;
    }

    return output;
};

const extractInstance = (node) => {
    const requiredProps = [
        // Dimensions
        "width",
        "height",

        // Child layout
        "layoutAlign",
        "layoutGrow",

        "absoluteBoundingBox",
        "componentId",
        "componentProperties",
    ];

    const output = {};

    for (const prop of requiredProps) {
        if (node.hasOwnProperty(prop)) {
            output[prop] = node[prop];
        }
    }

    return output;
};

const ignoreNodes = [
    "TABLE",
    "TABLE_CELL",
    "STICKY",
    "SHAPE_WITH_TEXT",
    "CONNECTOR",
    "WASHI_TAPE",
    "SLICE",
    "TEXT_PATH",
    "STAR",
    "LINE",
    "REGULAR_POLYGON",
    "BOOLEAN_OPERATION",
    "VECTOR",
    "ELLIPSE",
    "RECTANGLE",
];

export const isVisible = (node) => {
    return node.visible ?? !ignoreNodes.includes(node.type) ?? true;
};

export const extractor = (node) => {
    const common = {
        id: node.id,
        name: node.name,
        type: node.type,
    };

    switch (node.type) {
        case "TEXT":
            return { ...common, ...extractText(node) };

        case "INSTANCE":
            return { ...common, ...extractInstance(node) };

        case "FRAME":
        case "COMPONENT":
            return { ...common, ...extractFrame(node) };

        default:
            return common;
    }
};
