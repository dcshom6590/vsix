import { extractor, isVisible } from "./extractors.mjs";

export const nodeWalker = (node) => {
    const newNode = extractor(node);

    if (Array.isArray(node.children)) {
        newNode.children = node.children
            .filter(child => isVisible(child))
            .map(child => nodeWalker(child));
    }

    return newNode;
}