export const paddingToCSS = (node) => {
    const { paddingTop, paddingRight, paddingBottom, paddingLeft } = node;

    // All equal → 1 value
    if (paddingTop === paddingRight &&
        paddingTop === paddingBottom &&
        paddingTop === paddingLeft) {
        return paddingTop;
    }

    // Top/bottom equal AND left/right equal → 2 values
    if (paddingTop === paddingBottom && paddingLeft === paddingRight) {
        return `${paddingTop} ${paddingLeft}`;
    }

    // Left/right equal → 3 values
    if (paddingLeft === paddingRight) {
        return `${paddingTop} ${paddingLeft} ${paddingBottom}`;
    }

    // All different → 4 values
    return `${paddingTop} ${paddingRight} ${paddingBottom} ${paddingLeft}`;
}