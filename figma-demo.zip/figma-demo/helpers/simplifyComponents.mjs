export const simplifyComponents = (
    aggregatedComponents,
    aggregatedComponentSets
) => {
    return Object.fromEntries(
        Object.entries(aggregatedComponents)
            .filter(([_, comp]) => comp.componentSetId)
            .map(([id, comp]) => {
                const componentSet = aggregatedComponentSets[comp.componentSetId];
                return [
                    id,
                    {
                        id,
                        name: comp.name,
                        componentSetName: componentSet.name,
                        componentSetDescription: componentSet.description,
                    },
                ]
            }),
    );
}