function isVisible(element) {
    return element.visible ?? true;
}

function shouldProcessNode(node, options) {
    // Skip invisible nodes
    if (!isVisible(node)) {
        return false;
    }

    // Apply custom node filter if provided
    if (options.nodeFilter && !options.nodeFilter(node)) {
        return false;
    }

    return true;
}

function buildSimplifiedFrameValues(n) {
    if (!isFrame(n)) {
        return { mode: "none" };
    }

    const frameValues = {
        mode:
            !n.layoutMode || n.layoutMode === "NONE"
                ? "none"
                : n.layoutMode === "HORIZONTAL"
                    ? "row"
                    : "column",
    };

    const overflowScroll = [];
    if (n.overflowDirection?.includes("HORIZONTAL")) overflowScroll.push("x");
    if (n.overflowDirection?.includes("VERTICAL")) overflowScroll.push("y");
    if (overflowScroll.length > 0) frameValues.overflowScroll = overflowScroll;

    if (frameValues.mode === "none") {
        return frameValues;
    }

    // TODO: convertAlign should be two functions, one for justifyContent and one for alignItems
    frameValues.justifyContent = convertAlign(n.primaryAxisAlignItems ?? "MIN", {
        children: n.children,
        axis: "primary",
        mode: frameValues.mode,
    });
    frameValues.alignItems = convertAlign(n.counterAxisAlignItems ?? "MIN", {
        children: n.children,
        axis: "counter",
        mode: frameValues.mode,
    });
    frameValues.alignSelf = convertSelfAlign(n.layoutAlign);

    // Only include wrap if it's set to WRAP, since flex layouts don't default to wrapping
    frameValues.wrap = n.layoutWrap === "WRAP" ? true : undefined;
    frameValues.gap = n.itemSpacing ? `${n.itemSpacing ?? 0}px` : undefined;
    // gather padding
    if (n.paddingTop || n.paddingBottom || n.paddingLeft || n.paddingRight) {
        frameValues.padding = generateCSSShorthand({
            top: n.paddingTop ?? 0,
            right: n.paddingRight ?? 0,
            bottom: n.paddingBottom ?? 0,
            left: n.paddingLeft ?? 0,
        });
    }

    return frameValues;
}

function buildSimplifiedLayout(
    n,
    parent,
) {
    const frameValues = buildSimplifiedFrameValues(n);
    const layoutValues = buildSimplifiedLayoutValues(n, parent, frameValues.mode) || {};

    return { ...frameValues, ...layoutValues };
}

function buildSimplifiedLayoutValues(
    n,
    parent,
    mode
) {
    if (!isLayout(n)) return undefined;

    const layoutValues = { mode };

    layoutValues.sizing = {
        horizontal: convertSizing(n.layoutSizingHorizontal),
        vertical: convertSizing(n.layoutSizingVertical),
    };

    // Only include positioning-related properties if parent layout isn't flex or if the node is absolute
    if (
        // If parent is a frame but not an AutoLayout, or if the node is absolute, include positioning-related properties
        isFrame(parent) &&
        !isInAutoLayoutFlow(n, parent)
    ) {
        if (n.layoutPositioning === "ABSOLUTE") {
            layoutValues.position = "absolute";
        }
        if (n.absoluteBoundingBox && parent.absoluteBoundingBox) {
            layoutValues.locationRelativeToParent = {
                x: pixelRound(n.absoluteBoundingBox.x - parent.absoluteBoundingBox.x),
                y: pixelRound(n.absoluteBoundingBox.y - parent.absoluteBoundingBox.y),
            };
        }
    }

    // Handle dimensions based on layout growth and alignment
    if (isRectangle("absoluteBoundingBox", n)) {
        const dimensions = {};

        // Only include dimensions that aren't meant to stretch
        if (mode === "row") {
            // AutoLayout row, only include dimensions if the node is not growing
            if (!n.layoutGrow && n.layoutSizingHorizontal == "FIXED")
                dimensions.width = n.absoluteBoundingBox.width;
            if (n.layoutAlign !== "STRETCH" && n.layoutSizingVertical == "FIXED")
                dimensions.height = n.absoluteBoundingBox.height;
        } else if (mode === "column") {
            // AutoLayout column, only include dimensions if the node is not growing
            if (n.layoutAlign !== "STRETCH" && n.layoutSizingHorizontal == "FIXED")
                dimensions.width = n.absoluteBoundingBox.width;
            if (!n.layoutGrow && n.layoutSizingVertical == "FIXED")
                dimensions.height = n.absoluteBoundingBox.height;

            if (n.preserveRatio) {
                dimensions.aspectRatio = n.absoluteBoundingBox?.width / n.absoluteBoundingBox?.height;
            }
        } else {
            // Node is not an AutoLayout. Include dimensions if the node is not growing (which it should never be)
            if (!n.layoutSizingHorizontal || n.layoutSizingHorizontal === "FIXED") {
                dimensions.width = n.absoluteBoundingBox.width;
            }
            if (!n.layoutSizingVertical || n.layoutSizingVertical === "FIXED") {
                dimensions.height = n.absoluteBoundingBox.height;
            }
        }

        if (Object.keys(dimensions).length > 0) {
            if (dimensions.width) {
                dimensions.width = pixelRound(dimensions.width);
            }
            if (dimensions.height) {
                dimensions.height = pixelRound(dimensions.height);
            }
            layoutValues.dimensions = dimensions;
        }
    }

    return layoutValues;
}

function isFrame(val) {
    return (
        typeof val === "object" &&
        !!val &&
        "clipsContent" in val &&
        typeof val.clipsContent === "boolean"
    );
}

function convertSizing(
    s,
) {
    if (s === "FIXED") return "fixed";
    if (s === "FILL") return "fill";
    if (s === "HUG") return "hug";
    return undefined;
}

function isRectangle(
    key,
    obj,
) {
    const recordObj = obj;
    return (
        typeof obj === "object" &&
        !!obj &&
        key in recordObj &&
        typeof recordObj[key] === "object" &&
        !!recordObj[key] &&
        "x" in recordObj[key] &&
        "y" in recordObj[key] &&
        "width" in recordObj[key] &&
        "height" in recordObj[key]
    );
}

function pixelRound(num) {
    if (isNaN(num)) {
        throw new TypeError(`Input must be a valid number`);
    }
    return Number(Number(num).toFixed(2));
}

function findOrCreateVar(globalVars, value, prefix) {
    // Check if the same value already exists
    const [existingVarId] =
        Object.entries(globalVars.styles).find(
            ([_, existingValue]) => JSON.stringify(existingValue) === JSON.stringify(value),
        ) ?? [];

    if (existingVarId) {
        return existingVarId;
    }

    // Create a new variable if it doesn't exist
    const varId = generateVarId(prefix);
    globalVars.styles[varId] = value;
    return varId;
}

function generateVarId(prefix = "var") {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let result = "";

    for (let i = 0; i < 6; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }

    return `${prefix}_${result}`;
}

function isTextNode(
    n,
) {
    return n.type === "TEXT";
}

function hasTextStyle(
    n,
) {
    return hasValue("style", n) && Object.keys(n.style).length > 0;
}


function hasValue(
    key,
    obj,
    typeGuard,
) {
    const isObject = typeof obj === "object" && obj !== null;
    if (!isObject || !(key in obj)) return false;
    const val = (obj)[key];
    return typeGuard ? typeGuard(val) : val !== undefined;
}

function isLayout(val) {
    return (
        typeof val === "object" &&
        !!val &&
        "absoluteBoundingBox" in val &&
        typeof val.absoluteBoundingBox === "object" &&
        !!val.absoluteBoundingBox &&
        "x" in val.absoluteBoundingBox &&
        "y" in val.absoluteBoundingBox &&
        "width" in val.absoluteBoundingBox &&
        "height" in val.absoluteBoundingBox
    );
}

function getDirection(
    axis,
    mode,
) {
    switch (axis) {
        case "primary":
            switch (mode) {
                case "row":
                    return "horizontal";
                case "column":
                    return "vertical";
            }
        case "counter":
            switch (mode) {
                case "row":
                    return "horizontal";
                case "column":
                    return "vertical";
            }
    }
}

function generateCSSShorthand(
    values,
    {
        ignoreZero = true,
        suffix = "px",
    } = {},
) {
    const { top, right, bottom, left } = values;
    if (ignoreZero && top === 0 && right === 0 && bottom === 0 && left === 0) {
        return undefined;
    }
    if (top === right && right === bottom && bottom === left) {
        return `${top}${suffix}`;
    }
    if (right === left) {
        if (top === bottom) {
            return `${top}${suffix} ${right}${suffix}`;
        }
        return `${top}${suffix} ${right}${suffix} ${bottom}${suffix}`;
    }
    return `${top}${suffix} ${right}${suffix} ${bottom}${suffix} ${left}${suffix}`;
}

function extractTextStyle(n) {
    if (hasTextStyle(n)) {
        const style = n.style;
        const textStyle = {
            fontFamily: style.fontFamily,
            fontWeight: style.fontWeight,
            fontSize: style.fontSize,
            lineHeight:
                "lineHeightPx" in style && style.lineHeightPx && style.fontSize
                    ? `${style.lineHeightPx / style.fontSize}em`
                    : undefined,
            letterSpacing:
                style.letterSpacing && style.letterSpacing !== 0 && style.fontSize
                    ? `${(style.letterSpacing / style.fontSize) * 100}%`
                    : undefined,
            textCase: style.textCase,
            textAlignHorizontal: style.textAlignHorizontal,
            textAlignVertical: style.textAlignVertical,
        };
        return textStyle;
    }
}

function isTruthy(
    data,
) {
    return Boolean(data);
}

function isInAutoLayoutFlow(node, parent) {
    const autoLayoutModes = ["HORIZONTAL", "VERTICAL"];
    return (
        isFrame(parent) &&
        autoLayoutModes.includes(parent.layoutMode ?? "NONE") &&
        isLayout(node) &&
        node.layoutPositioning !== "ABSOLUTE"
    );
}

function extractNodeText(n) {
    if (hasValue("characters", n, isTruthy)) {
        return n.characters;
    }
}

function convertAlign(
    axisAlign,
    stretch
) {
    if (stretch && stretch.mode !== "none") {
        const { children, mode, axis } = stretch;

        // Compute whether to check horizontally or vertically based on axis and direction
        const direction = getDirection(axis, mode);

        const shouldStretch =
            children.length > 0 &&
            children.reduce((shouldStretch, c) => {
                if (!shouldStretch) return false;
                if ("layoutPositioning" in c && c.layoutPositioning === "ABSOLUTE") return true;
                if (direction === "horizontal") {
                    return "layoutSizingHorizontal" in c && c.layoutSizingHorizontal === "FILL";
                } else if (direction === "vertical") {
                    return "layoutSizingVertical" in c && c.layoutSizingVertical === "FILL";
                }
                return false;
            }, true);

        if (shouldStretch) return "stretch";
    }

    switch (axisAlign) {
        case "MIN":
            // MIN, AKA flex-start, is the default alignment
            return undefined;
        case "MAX":
            return "flex-end";
        case "CENTER":
            return "center";
        case "SPACE_BETWEEN":
            return "space-between";
        case "BASELINE":
            return "baseline";
        default:
            return undefined;
    }
}

function convertSelfAlign(align) {
    switch (align) {
        case "MIN":
            // MIN, AKA flex-start, is the default alignment
            return undefined;
        case "MAX":
            return "flex-end";
        case "CENTER":
            return "center";
        case "STRETCH":
            return "stretch";
        default:
            return undefined;
    }
}


function processNodeWithExtractors(
    node,
    extractors,
    context,
    options,
) {
    if (!shouldProcessNode(node, options)) {
        return null;
    }

    // Always include base metadata
    const result = {
        id: node.id,
        name: node.name,
        type: node.type === "VECTOR" ? "IMAGE-SVG" : node.type,
    };

    // Apply all extractors to this node in a single pass
    for (const extractor of extractors) {
        extractor(node, result, context);
    }

    // Handle children recursively
    if (shouldTraverseChildren(node, context, options)) {
        const childContext = {
            ...context,
            currentDepth: context.currentDepth + 1,
            parent: node,
        };

        // Use the same pattern as the existing parseNode function
        if (hasValue("children", node) && node.children.length > 0) {
            const children = node.children
                .filter((child) => shouldProcessNode(child, options))
                .map((child) => processNodeWithExtractors(child, extractors, childContext, options))
                .filter((child) => child !== null);

            if (children.length > 0) {
                // Allow custom logic to modify parent and control which children to include
                const childrenToInclude = options.afterChildren
                    ? options.afterChildren(node, result, children)
                    : children;

                if (childrenToInclude.length > 0) {
                    result.children = childrenToInclude;
                }
            }
        }
    }

    return result;
}

function extractFromDesign(
    nodes,
    extractors,
    options,
    globalVars = { styles: {} },
) {
    const context = {
        globalVars,
        currentDepth: 0,
    };

    const processedNodes = nodes
        .filter((node) => shouldProcessNode(node, options))
        .map((node) => processNodeWithExtractors(node, extractors, context, options))
        .filter((node) => node !== null);

    return {
        nodes: processedNodes,
        globalVars: context.globalVars,
    };
}

function parseAPIResponse(data) {
    const aggregatedComponents = {};
    const aggregatedComponentSets = {};
    let extraStyles = {};
    let nodesToParse;

    if ("nodes" in data) {
        // GetFileNodesResponse
        const nodeResponses = Object.values(data.nodes);
        nodeResponses.forEach((nodeResponse) => {
            if (nodeResponse.components) {
                Object.assign(aggregatedComponents, nodeResponse.components);
            }
            if (nodeResponse.componentSets) {
                Object.assign(aggregatedComponentSets, nodeResponse.componentSets);
            }
            if (nodeResponse.styles) {
                Object.assign(extraStyles, nodeResponse.styles);
            }
        });
        nodesToParse = nodeResponses.map((n) => n.document).filter(isVisible);
    } else {
        // GetFileResponse
        Object.assign(aggregatedComponents, data.components);
        Object.assign(aggregatedComponentSets, data.componentSets);
        if (data.styles) {
            extraStyles = data.styles;
        }
        nodesToParse = data.document.children.filter(isVisible);
    }

    const { name } = data;

    return {
        metadata: {
            name,
        },
        rawNodes: nodesToParse,
        extraStyles,
        components: aggregatedComponents,
        componentSets: aggregatedComponentSets,
    };
}


export function simplifyRawFigmaObject(
    apiResponse,
    nodeExtractors,
    options
) {
    // Extract components, componentSets, and raw nodes from API response
    const { metadata, rawNodes, components, componentSets, extraStyles } =
        parseAPIResponse(apiResponse);

    // Process nodes using the flexible extractor system
    const globalVars = { styles: {}, extraStyles };
    const { nodes: extractedNodes, globalVars: finalGlobalVars } = extractFromDesign(
        rawNodes,
        nodeExtractors,
        options,
        globalVars,
    );

    // Return complete design
    return {
        ...metadata,
        nodes: extractedNodes,
        components: simplifyComponents(components),
        componentSets: simplifyComponentSets(componentSets),
        globalVars: { styles: finalGlobalVars.styles },
    };
}

function generateTransformHash(transform) {
    const values = transform.flat();
    const hash = values.reduce((acc, val) => {
        // Simple hash function - convert to string and create checksum
        const str = val.toString();
        for (let i = 0; i < str.length; i++) {
            acc = ((acc << 5) - acc + str.charCodeAt(i)) & 0xffffffff;
        }
        return acc;
    }, 0);

    // Convert to positive hex string, take first 6 chars
    return Math.abs(hash).toString(16).substring(0, 6);
}

function handleImageTransform(
    imageTransform,
) {
    const transformHash = generateTransformHash(imageTransform);
    return {
        needsCropping: true,
        requiresImageDimensions: false,
        cropTransform: imageTransform,
        filenameSuffix: `${transformHash}`,
    };
}

function mapAngularGradient(
    gradientStops,
    center,
    angleHandle,
    widthHandle,
    elementBounds,
) {
    const centerX = Math.round(center.x * 100);
    const centerY = Math.round(center.y * 100);

    const angle =
        Math.atan2(angleHandle.y - center.y, angleHandle.x - center.x) * (180 / Math.PI) + 90;

    const stops = gradientStops
        .map(({ position, color }) => {
            const cssColor = formatRGBAColor(color, 1);
            return `${cssColor} ${Math.round(position * 100)}%`;
        })
        .join(", ");

    return {
        stops,
        cssGeometry: `from ${Math.round(angle)}deg at ${centerX}% ${centerY}%`,
    };
}

function mapDiamondGradient(
    gradientStops,
    center,
    edge,
    widthHandle,
    elementBounds,
) {
    const centerX = Math.round(center.x * 100);
    const centerY = Math.round(center.y * 100);

    const stops = gradientStops
        .map(({ position, color }) => {
            const cssColor = formatRGBAColor(color, 1);
            return `${cssColor} ${Math.round(position * 100)}%`;
        })
        .join(", ");

    return {
        stops,
        cssGeometry: `ellipse at ${centerX}% ${centerY}%`,
    };
}

function findExtendedLineIntersections(start, end) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;

    // Handle degenerate case
    if (Math.abs(dx) < 1e-10 && Math.abs(dy) < 1e-10) {
        return [];
    }

    const intersections = [];

    // Check intersection with each edge of the unit square [0,1] x [0,1]
    // Top edge (y = 0)
    if (Math.abs(dy) > 1e-10) {
        const t = -start.y / dy;
        const x = start.x + t * dx;
        if (x >= 0 && x <= 1) {
            intersections.push(t);
        }
    }

    // Bottom edge (y = 1)
    if (Math.abs(dy) > 1e-10) {
        const t = (1 - start.y) / dy;
        const x = start.x + t * dx;
        if (x >= 0 && x <= 1) {
            intersections.push(t);
        }
    }

    // Left edge (x = 0)
    if (Math.abs(dx) > 1e-10) {
        const t = -start.x / dx;
        const y = start.y + t * dy;
        if (y >= 0 && y <= 1) {
            intersections.push(t);
        }
    }

    // Right edge (x = 1)
    if (Math.abs(dx) > 1e-10) {
        const t = (1 - start.x) / dx;
        const y = start.y + t * dy;
        if (y >= 0 && y <= 1) {
            intersections.push(t);
        }
    }

    // Remove duplicates and sort
    const uniqueIntersections = [
        ...new Set(intersections.map((t) => Math.round(t * 1000000) / 1000000)),
    ];
    return uniqueIntersections.sort((a, b) => a - b);
}

function mapLinearGradient(
    gradientStops,
    start,
    end,
    elementBounds,
) {
    // Calculate the gradient line in element space
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const gradientLength = Math.sqrt(dx * dx + dy * dy);

    // Handle degenerate case
    if (gradientLength === 0) {
        const stops = gradientStops
            .map(({ position, color }) => {
                const cssColor = formatRGBAColor(color, 1);
                return `${cssColor} ${Math.round(position * 100)}%`;
            })
            .join(", ");
        return { stops, cssGeometry: "0deg" };
    }

    // Calculate angle for CSS
    const angle = Math.atan2(dy, dx) * (180 / Math.PI) + 90;

    // Find where the extended gradient line intersects the element boundaries
    const extendedIntersections = findExtendedLineIntersections(start, end);

    if (extendedIntersections.length >= 2) {
        // The gradient line extended to fill the element
        const fullLineStart = Math.min(extendedIntersections[0], extendedIntersections[1]);
        const fullLineEnd = Math.max(extendedIntersections[0], extendedIntersections[1]);
        const fullLineLength = fullLineEnd - fullLineStart;

        // Map gradient stops from the Figma line segment to the full CSS line
        const mappedStops = gradientStops.map(({ position, color }) => {
            const cssColor = formatRGBAColor(color, 1);

            // Position along the Figma gradient line (0 = start handle, 1 = end handle)
            const figmaLinePosition = position;

            // The Figma line spans from t=0 to t=1
            // The full extended line spans from fullLineStart to fullLineEnd
            // Map the figma position to the extended line
            const tOnExtendedLine = figmaLinePosition * (1 - 0) + 0; // This is just figmaLinePosition
            const extendedPosition = (tOnExtendedLine - fullLineStart) / (fullLineEnd - fullLineStart);
            const clampedPosition = Math.max(0, Math.min(1, extendedPosition));

            return `${cssColor} ${Math.round(clampedPosition * 100)}%`;
        });

        return {
            stops: mappedStops.join(", "),
            cssGeometry: `${Math.round(angle)}deg`,
        };
    }

    // Fallback to simple gradient if intersection calculation fails
    const mappedStops = gradientStops.map(({ position, color }) => {
        const cssColor = formatRGBAColor(color, 1);
        return `${cssColor} ${Math.round(position * 100)}%`;
    });

    return {
        stops: mappedStops.join(", "),
        cssGeometry: `${Math.round(angle)}deg`,
    };
}


function parsePatternPaint(
    raw,
) {
    /**
     * The only CSS-like repeat value supported by Figma is repeat.
     *
     * They also have hexagonal horizontal and vertical repeats, but
     * those aren't easy to pull off in CSS, so we just use repeat.
     */
    let backgroundRepeat = "repeat";

    let horizontal = "left";
    switch (raw.horizontalAlignment) {
        case "START":
            horizontal = "left";
            break;
        case "CENTER":
            horizontal = "center";
            break;
        case "END":
            horizontal = "right";
            break;
    }

    let vertical = "top";
    switch (raw.verticalAlignment) {
        case "START":
            vertical = "top";
            break;
        case "CENTER":
            vertical = "center";
            break;
        case "END":
            vertical = "bottom";
            break;
    }

    return {
        type: raw.type,
        patternSource: {
            type: "IMAGE-PNG",
            nodeId: raw.sourceNodeId,
        },
        backgroundRepeat,
        backgroundSize: `${Math.round(raw.scalingFactor * 100)}%`,
        backgroundPosition: `${horizontal} ${vertical}`,
    };
}


function translateScaleMode(
    scaleMode,
    hasChildren,
    scalingFactor,
) {
    const isBackground = hasChildren;

    switch (scaleMode) {
        case "FILL":
            // Image covers entire container, may be cropped
            return {
                css: isBackground
                    ? { backgroundSize: "cover", backgroundRepeat: "no-repeat", isBackground: true }
                    : { objectFit: "cover", isBackground: false },
                processing: { needsCropping: false, requiresImageDimensions: false },
            };

        case "FIT":
            // Image fits entirely within container, may have empty space
            return {
                css: isBackground
                    ? { backgroundSize: "contain", backgroundRepeat: "no-repeat", isBackground: true }
                    : { objectFit: "contain", isBackground: false },
                processing: { needsCropping: false, requiresImageDimensions: false },
            };

        case "TILE":
            // Image repeats to fill container at specified scale
            // Always treat as background image (can't tile an <img> tag)
            return {
                css: {
                    backgroundRepeat: "repeat",
                    backgroundSize: scalingFactor
                        ? `calc(var(--original-width) * ${scalingFactor}) calc(var(--original-height) * ${scalingFactor})`
                        : "auto",
                    isBackground: true,
                },
                processing: { needsCropping: false, requiresImageDimensions: true },
            };

        case "STRETCH":
            // Figma calls crop "STRETCH" in its API.
            return {
                css: isBackground
                    ? { backgroundSize: "100% 100%", backgroundRepeat: "no-repeat", isBackground: true }
                    : { objectFit: "fill", isBackground: false },
                processing: { needsCropping: false, requiresImageDimensions: false },
            };

        default:
            return {
                css: {},
                processing: { needsCropping: false, requiresImageDimensions: false },
            };
    }
}

function parsePaint(raw, hasChildren = false) {
    if (raw.type === "IMAGE") {
        const baseImageFill = {
            type: "IMAGE",
            imageRef: raw.imageRef,
            scaleMode: raw.scaleMode,
            scalingFactor: raw.scalingFactor,
        };

        // Get CSS properties and processing metadata from scale mode
        // TILE mode always needs to be treated as background image (can't tile an <img> tag)
        const isBackground = hasChildren || baseImageFill.scaleMode === "TILE";
        const { css, processing } = translateScaleMode(
            baseImageFill.scaleMode,
            isBackground,
            raw.scalingFactor,
        );

        // Combine scale mode processing with transform processing if needed
        // Transform processing (cropping) takes precedence over scale mode processing
        let finalProcessing = processing;
        if (raw.imageTransform) {
            const transformProcessing = handleImageTransform(raw.imageTransform);
            finalProcessing = {
                ...processing,
                ...transformProcessing,
                // Keep requiresImageDimensions from scale mode (needed for TILE)
                requiresImageDimensions:
                    processing.requiresImageDimensions || transformProcessing.requiresImageDimensions,
            };
        }

        return {
            ...baseImageFill,
            ...css,
            imageDownloadArguments: finalProcessing,
        };
    } else if (raw.type === "SOLID") {
        // treat as SOLID
        const { hex, opacity } = convertColor(raw.color, raw.opacity);
        if (opacity === 1) {
            return hex;
        } else {
            return formatRGBAColor(raw.color, opacity);
        }
    } else if (raw.type === "PATTERN") {
        return parsePatternPaint(raw);
    } else if (
        ["GRADIENT_LINEAR", "GRADIENT_RADIAL", "GRADIENT_ANGULAR", "GRADIENT_DIAMOND"].includes(
            raw.type,
        )
    ) {
        return {
            type: raw.type,
            gradient: convertGradientToCss(raw),
        };
    } else {
        throw new Error(`Unknown paint type: ${raw.type}`);
    }
}


const layoutExtractor = (node, result, context) => {
    const layout = buildSimplifiedLayout(node, context.parent);
    if (Object.keys(layout).length > 1) {
        result.layout = findOrCreateVar(context.globalVars, layout, "layout");
    }
};

const textExtractor = (node, result, context) => {
    // Extract text content
    if (isTextNode(node)) {
        result.text = extractNodeText(node);
    }

    // Extract text style
    if (hasTextStyle(node)) {
        const textStyle = extractTextStyle(node);
        if (textStyle) {
            // Prefer Figma named style when available
            const styleName = getStyleName(node, context, ["text", "typography"]);
            if (styleName) {
                context.globalVars.styles[styleName] = textStyle;
                result.textStyle = styleName;
            } else {
                result.textStyle = findOrCreateVar(context.globalVars, textStyle, "style");
            }
        }
    }
};


const visualsExtractor = (node, result, context) => {
    // Check if node has children to determine CSS properties
    const hasChildren =
        hasValue("children", node) && Array.isArray(node.children) && node.children.length > 0;

    // fills
    if (hasValue("fills", node) && Array.isArray(node.fills) && node.fills.length) {
        const fills = node.fills.map((fill) => parsePaint(fill, hasChildren)).reverse();
        const styleName = getStyleName(node, context, ["fill", "fills"]);
        if (styleName) {
            context.globalVars.styles[styleName] = fills;
            result.fills = styleName;
        } else {
            result.fills = findOrCreateVar(context.globalVars, fills, "fill");
        }
    }

    // strokes
    const strokes = buildSimplifiedStrokes(node, hasChildren);
    if (strokes.colors.length) {
        const styleName = getStyleName(node, context, ["stroke", "strokes"]);
        if (styleName) {
            // Only colors are stylable; keep other stroke props on the node
            context.globalVars.styles[styleName] = strokes.colors;
            result.strokes = styleName;
            if (strokes.strokeWeight) result.strokeWeight = strokes.strokeWeight;
            if (strokes.strokeDashes) result.strokeDashes = strokes.strokeDashes;
            if (strokes.strokeWeights) result.strokeWeights = strokes.strokeWeights;
        } else {
            result.strokes = findOrCreateVar(context.globalVars, strokes, "stroke");
        }
    }

    // effects
    const effects = buildSimplifiedEffects(node);
    if (Object.keys(effects).length) {
        const styleName = getStyleName(node, context, ["effect", "effects"]);
        if (styleName) {
            // Effects styles store only the effect values
            context.globalVars.styles[styleName] = effects;
            result.effects = styleName;
        } else {
            result.effects = findOrCreateVar(context.globalVars, effects, "effect");
        }
    }

    // opacity
    if (hasValue("opacity", node) && typeof node.opacity === "number" && node.opacity !== 1) {
        result.opacity = node.opacity;
    }

    // border radius
    if (hasValue("cornerRadius", node) && typeof node.cornerRadius === "number") {
        result.borderRadius = `${node.cornerRadius}px`;
    }
    if (hasValue("rectangleCornerRadii", node, isRectangleCornerRadii)) {
        result.borderRadius = `${node.rectangleCornerRadii[0]}px ${node.rectangleCornerRadii[1]}px ${node.rectangleCornerRadii[2]}px ${node.rectangleCornerRadii[3]}px`;
    }
};

const componentExtractor = (node, result, _context) => {
    if (node.type === "INSTANCE") {
        if (hasValue("componentId", node)) {
            result.componentId = node.componentId;
        }

        // Add specific properties for instances of components
        if (hasValue("componentProperties", node)) {
            result.componentProperties = Object.entries(node.componentProperties ?? {}).map(
                ([name, { value, type }]) => ({
                    name,
                    value: value.toString(),
                    type,
                }),
            );
        }
    }
};

function convertColor(color, opacity = 1) {
    const r = Math.round(color.r * 255);
    const g = Math.round(color.g * 255);
    const b = Math.round(color.b * 255);

    // Alpha channel defaults to 1. If opacity and alpha are both and < 1, their effects are multiplicative
    const a = Math.round(opacity * color.a * 100) / 100;

    const hex = ("#" +
        ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase());

    return { hex, opacity: a };
}

function mapGradientStops(
    gradient,
    elementBounds = { width: 1, height: 1 },
) {
    const handles = gradient.gradientHandlePositions;
    if (!handles || handles.length < 2) {
        const stops = gradient.gradientStops
            .map(({ position, color }) => {
                const cssColor = formatRGBAColor(color, 1);
                return `${cssColor} ${Math.round(position * 100)}%`;
            })
            .join(", ");
        return { stops, cssGeometry: "0deg" };
    }

    const [handle1, handle2, handle3] = handles;

    switch (gradient.type) {
        case "GRADIENT_LINEAR": {
            return mapLinearGradient(gradient.gradientStops, handle1, handle2, elementBounds);
        }
        case "GRADIENT_RADIAL": {
            return mapRadialGradient(gradient.gradientStops, handle1, handle2, handle3, elementBounds);
        }
        case "GRADIENT_ANGULAR": {
            return mapAngularGradient(gradient.gradientStops, handle1, handle2, handle3, elementBounds);
        }
        case "GRADIENT_DIAMOND": {
            return mapDiamondGradient(gradient.gradientStops, handle1, handle2, handle3, elementBounds);
        }
        default: {
            const stops = gradient.gradientStops
                .map(({ position, color }) => {
                    const cssColor = formatRGBAColor(color, 1);
                    return `${cssColor} ${Math.round(position * 100)}%`;
                })
                .join(", ");
            return { stops, cssGeometry: "0deg" };
        }
    }
}

function formatRGBAColor(color, opacity = 1) {
    const r = Math.round(color.r * 255);
    const g = Math.round(color.g * 255);
    const b = Math.round(color.b * 255);
    // Alpha channel defaults to 1. If opacity and alpha are both and < 1, their effects are multiplicative
    const a = Math.round(opacity * color.a * 100) / 100;

    return `rgba(${r}, ${g}, ${b}, ${a})`;
}

function getStyleName(
    node,
    context,
    keys,
) {
    if (!hasValue("styles", node)) return undefined;
    const styleMap = node.styles;
    for (const key of keys) {
        const styleId = styleMap[key];
        if (styleId) {
            const meta = context.globalVars.extraStyles?.[styleId];
            if (meta?.name) return meta.name;
        }
    }
    return undefined;
}

function simplifyDropShadow(effect) {
    return `${effect.offset.x}px ${effect.offset.y}px ${effect.radius}px ${effect.spread ?? 0}px ${formatRGBAColor(effect.color)}`;
}

function simplifyInnerShadow(effect) {
    return `inset ${effect.offset.x}px ${effect.offset.y}px ${effect.radius}px ${effect.spread ?? 0}px ${formatRGBAColor(effect.color)}`;
}

function simplifyBlur(effect) {
    return `blur(${effect.radius}px)`;
}

function shouldTraverseChildren(
    node,
    context,
    options,
) {
    // Check depth limit
    if (options.maxDepth !== undefined && context.currentDepth >= options.maxDepth) {
        return false;
    }

    return true;
}

function simplifyComponents(
    aggregatedComponents,
) {
    return Object.fromEntries(
        Object.entries(aggregatedComponents).map(([id, comp]) => [
            id,
            {
                id,
                key: comp.key,
                name: comp.name,
                componentSetId: comp.componentSetId,
            },
        ]),
    );
}

function simplifyComponentSets(
    aggregatedComponentSets,
) {
    return Object.fromEntries(
        Object.entries(aggregatedComponentSets).map(([id, set]) => [
            id,
            {
                id,
                key: set.key,
                name: set.name,
                description: set.description,
            },
        ]),
    );
}


function isRectangleCornerRadii(val) {
    return Array.isArray(val) && val.length === 4 && val.every((v) => typeof v === "number");
}

function buildSimplifiedEffects(n) {
    if (!hasValue("effects", n)) return {};
    const effects = n.effects.filter((e) => e.visible);

    // Handle drop and inner shadows (both go into CSS box-shadow)
    const dropShadows = effects
        .filter((e) => e.type === "DROP_SHADOW")
        .map(simplifyDropShadow);

    const innerShadows = effects
        .filter((e) => e.type === "INNER_SHADOW")
        .map(simplifyInnerShadow);

    const boxShadow = [...dropShadows, ...innerShadows].join(", ");

    // Handle blur effects - separate by CSS property
    // Layer blurs use the CSS 'filter' property
    const filterBlurValues = effects
        .filter((e) => e.type === "LAYER_BLUR")
        .map(simplifyBlur)
        .join(" ");

    // Background blurs use the CSS 'backdrop-filter' property
    const backdropFilterValues = effects
        .filter((e) => e.type === "BACKGROUND_BLUR")
        .map(simplifyBlur)
        .join(" ");

    const result = {};

    if (boxShadow) {
        if (n.type === "TEXT") {
            result.textShadow = boxShadow;
        } else {
            result.boxShadow = boxShadow;
        }
    }
    if (filterBlurValues) result.filter = filterBlurValues;
    if (backdropFilterValues) result.backdropFilter = backdropFilterValues;

    return result;
}

function isStrokeWeights(val) {
    return (
        typeof val === "object" &&
        val !== null &&
        "top" in val &&
        "right" in val &&
        "bottom" in val &&
        "left" in val
    );
}

function buildSimplifiedStrokes(
    n,
    hasChildren = false,
) {
    let strokes = { colors: [] };
    if (hasValue("strokes", n) && Array.isArray(n.strokes) && n.strokes.length) {
        strokes.colors = n.strokes.filter(isVisible).map((stroke) => parsePaint(stroke, hasChildren));
    }

    if (hasValue("strokeWeight", n) && typeof n.strokeWeight === "number" && n.strokeWeight > 0) {
        strokes.strokeWeight = `${n.strokeWeight}px`;
    }

    if (hasValue("strokeDashes", n) && Array.isArray(n.strokeDashes) && n.strokeDashes.length) {
        strokes.strokeDashes = n.strokeDashes;
    }

    if (hasValue("individualStrokeWeights", n, isStrokeWeights)) {
        strokes.strokeWeight = generateCSSShorthand(n.individualStrokeWeights);
    }

    return strokes;
}

function mapRadialGradient(
    gradientStops,
    center,
    edge,
    widthHandle,
    elementBounds,
) {
    const centerX = Math.round(center.x * 100);
    const centerY = Math.round(center.y * 100);

    const stops = gradientStops
        .map(({ position, color }) => {
            const cssColor = formatRGBAColor(color, 1);
            return `${cssColor} ${Math.round(position * 100)}%`;
        })
        .join(", ");

    return {
        stops,
        cssGeometry: `circle at ${centerX}% ${centerY}%`,
    };
}

function convertGradientToCss(
    gradient
) {
    // Sort stops by position to ensure proper order
    const sortedGradient = {
        ...gradient,
        gradientStops: [...gradient.gradientStops].sort((a, b) => a.position - b.position),
    };

    // Map gradient stops using handle-based geometry
    const { stops, cssGeometry } = mapGradientStops(sortedGradient);

    switch (gradient.type) {
        case "GRADIENT_LINEAR": {
            return `linear-gradient(${cssGeometry}, ${stops})`;
        }

        case "GRADIENT_RADIAL": {
            return `radial-gradient(${cssGeometry}, ${stops})`;
        }

        case "GRADIENT_ANGULAR": {
            return `conic-gradient(${cssGeometry}, ${stops})`;
        }

        case "GRADIENT_DIAMOND": {
            return `radial-gradient(${cssGeometry}, ${stops})`;
        }

        default:
            return `linear-gradient(0deg, ${stops})`;
    }
}

const SVG_ELIGIBLE_TYPES = new Set([
    "IMAGE-SVG", // VECTOR nodes are converted to IMAGE-SVG, or containers that were collapsed
    "STAR",
    "LINE",
    "ELLIPSE",
    "REGULAR_POLYGON",
    "RECTANGLE",
]);


export const allExtractors = [layoutExtractor, textExtractor, visualsExtractor, componentExtractor];

export function collapseSvgContainers(
    node,
    result,
    children,
) {
    const allChildrenAreSvgEligible = children.every((child) =>
        SVG_ELIGIBLE_TYPES.has(child.type),
    );

    if (
        (node.type === "FRAME" || node.type === "GROUP" || node.type === "INSTANCE") &&
        allChildrenAreSvgEligible
    ) {
        // Collapse to IMAGE-SVG and omit children
        result.type = "IMAGE-SVG";
        return [];
    }

    // Include all children normally
    return children;
}
