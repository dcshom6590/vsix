import { fileURLToPath } from 'node:url';
import { readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";

import { allExtractors, collapseSvgContainers, simplifyRawFigmaObject } from './extractors/index.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const designPath = join(__dirname, '.', 'design1.json');
const apiResponse = JSON.parse(readFileSync(designPath, { encoding: "utf-8" }))

const depth = undefined;

const simplifiedDesign = simplifyRawFigmaObject(apiResponse, allExtractors, {
    maxDepth: depth,
    afterChildren: collapseSvgContainers,
});

const { nodes, globalVars, ...metadata } = simplifiedDesign;
const result = {
    metadata,
    nodes,
    globalVars,
};


writeFileSync(join(__dirname, 'simplifiedDesign1.json'), JSON.stringify(result, null, 2), { encoding: "utf-8" });