import { fileURLToPath } from 'node:url';
import { join, dirname } from "node:path";
import { writeFileSync } from "node:fs";

import simplifyResponse from './index.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const urls = [
    "https://www.figma.com/design/KOu0aHu1E4Jijn6sYrIjVU/Claim?node-id=4183-41272&t=2hYSstAsS7b7N1VW-4",
    "https://www.figma.com/design/KOu0aHu1E4Jijn6sYrIjVU/Claim?node-id=3455-14958&t=2hYSstAsS7b7N1VW-4s",
];

const X_FIGMA_TOKEN = 'figd_u2lJHq111DoF5GMUxxhqJCpxDyFyr8aomL7GaGV-'

const getFileKeyandNodeId = (url) => {
    // Extract file key (between /design/ and next /)
    const fileKeyMatch = url.match(/\/design\/([^\/]+)/);
    const fileKey = fileKeyMatch ? fileKeyMatch[1] : null;

    // Extract node-id and replace hyphen with colon
    const nodeIdMatch = url.match(/node-id=([^&]+)/);
    const nodeId = nodeIdMatch ? nodeIdMatch[1].replace('-', ':') : null;

    return {
        fileKey,
        nodeId
    };
};

const fetchFigmaJson = async (fileKey, nodeId) => {
    const url = `https://api.figma.com/v1/files/${fileKey}/nodes?ids=${nodeId}`;
    const res = await fetch(url, {
        method: 'GET',
        headers: {
            'X-Figma-Token': X_FIGMA_TOKEN
        }
    });

    return await res.json();
}

const fetcher = async (url) => {
    const { fileKey, nodeId } = getFileKeyandNodeId(url);
    const json = await fetchFigmaJson(fileKey, nodeId);

    const filename = (json?.nodes?.[nodeId]?.document?.name || fileKey) + '_' + (new Date().getTime()) + '.json';

    writeFileSync(join(__dirname, 'input', filename), JSON.stringify(json), { encoding: "utf-8" });

    writeFileSync(join(__dirname, 'output', filename), JSON.stringify(simplifyResponse(json)), { encoding: "utf-8" });
}

for (const url of urls) {
    await fetcher(url);
}