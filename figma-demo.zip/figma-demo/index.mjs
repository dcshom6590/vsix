// import { fileURLToPath } from 'node:url';
// import { readFileSync, writeFileSync } from "node:fs";
// import { join, dirname } from "node:path";

import { nodeWalker } from './helpers/nodeWalker.mjs';
import { simplifyComponents } from './helpers/simplifyComponents.mjs';

// const __filename = fileURLToPath(import.meta.url);
// const __dirname = dirname(__filename);

// const designPath = join(__dirname, '.', 'design.json');
// const apiResponse = JSON.parse(readFileSync(designPath, { encoding: "utf-8" }))

const simplifyResponse = (rawData) => {
    if (!rawData.hasOwnProperty("nodes")) return null;

    const rawNodes = Object.values(rawData.nodes);

    if (!rawNodes.length) return null;

    const { document, components, componentSets } = rawNodes[0];


    return {
        nodes: nodeWalker(document),
        components: simplifyComponents(components, componentSets),
    };

};

export default simplifyResponse;

// writeFileSync(join(__dirname, 'output.json'), JSON.stringify(simplifyResponse(apiResponse), null, 2), { encoding: "utf-8" });