import { fileURLToPath } from 'node:url';
import { join, dirname } from "node:path";
import { writeFileSync, readFileSync } from "node:fs";

import simplifyResponse from "./index.mjs";


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const filenames = ['m.json', 'd.json'];

for (const filename of filenames) {
    const content = readFileSync(join(__dirname, 'input', filename), { encoding: "utf-8" });
    const json = JSON.parse(content);
    writeFileSync(join(__dirname, 'output', filename), JSON.stringify(simplifyResponse(json)), { encoding: "utf-8" });
}

