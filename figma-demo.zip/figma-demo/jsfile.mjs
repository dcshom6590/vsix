import { glob } from "glob";

import { readFileSync, writeFileSync } from "fs";

const files = await glob("../mQuote/src/**/*.js", {
    ignore: ["node_modules/**"]
});

let output = [];

for (const file of files) {
    const content = readFileSync(file, "utf-8");
    const importLines = content.match(/^\s*import[\s\S]*?from\s+['"][^'"]+['"];?/gm) || [];
    const filteredImportLines = importLines.filter(line => line.includes("@material-ui/core") && line.includes("Button"));
    if (filteredImportLines.length > 0) {
        output.push(file)
        // output.push(filteredImportLines.join("\n") + "\n");
    }
}


writeFileSync("all-imports.txt", output.join(",").replaceAll('..\\mQuote\\src', "**"), "utf-8");